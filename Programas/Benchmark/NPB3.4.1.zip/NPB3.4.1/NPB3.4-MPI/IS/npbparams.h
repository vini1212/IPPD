#define CLASS 'A'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "01 Jul 2020"
#define NPBVERSION "3.4.1"
#define MPICC "mpicc"
#define CFLAGS "-O3"
#define CLINK "$(MPICC)"
#define CLINKFLAGS "$(CFLAGS)"
#define CMPI_LIB "(none)"
#define CMPI_INC "(none)"
